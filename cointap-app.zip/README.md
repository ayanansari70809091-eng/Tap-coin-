# Coin Tap - Android Build (No AppMint, No Watermark)

Ye tumhare "Coin Tap" game ka apna Capacitor + GitHub Actions setup hai. Koi third-party wrapper nahi, isliye koi "Made with X" watermark bhi kabhi nahi aayega.

## Setup (ek baar karna hai)

1. GitHub par naya repo banao (ya apna existing TapCoin repo use karo) - `ayanansari70809091-eng` account se.
2. Is poore folder (`cointap-app`) ka pura content us repo mein upload/push kar do. `node_modules` folder mat bhejo agar accidentally ban gaya ho - `.gitignore` already usko exclude karta hai.
3. GitHub par repo ke **Actions** tab mein jao - workflow apne aap chalega push hote hi.

## APK kahan milega

1. Repo ke **Actions** tab mein "Build Coin Tap APK" workflow open karo.
2. Sabse latest run pe click karo (green tick ka matlab success).
3. Neeche **Artifacts** section mein "coin-tap-debug-apk" milega - download kar lo, usme APK hoga.
4. Phone pe transfer karke install kar lo ("unknown sources" allow karna padega).

## Important notes

- **Ye debug build hai** - install/test/share karne ke liye bilkul sahi hai, koi paisa ya signing setup nahi chahiye. Agar future mein Google Play Store pe publish karna ho, tab proper release keystore banake signing add karni hogi (bata dena, help kar dunga).
- **Icon** tumhare purane AppMint APK se hi liya hai, so look same rahega.
- **`app-credentials.csv` wali cheez use nahi ki** - wo Client ID/Secret/HMAC key AppMint ke apne backend/account se related lagte hain, game code mein unka koi reference nahi hai. Agar wo kisi specific feature (push notifications, ads, etc.) ke liye chahiye the, bata dena - alag se dekh lenge ki naye setup mein kaise add karein. Waise bhi, aisi secret keys kabhi bhi seedha code/repo mein mat daalna agar repo public hai - GitHub "Settings > Secrets" mein daalna safe hota hai.
- Game logic bilkul waisa hi hai jaisa original file mein tha - localStorage se save/load same rahega, purana progress carry nahi hoga (naya package/app hai AppMint wale se alag), lekin naye installs se sab normal chalega.
