import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cointap.game',
  appName: 'Coin Tap',
  webDir: 'www'
};

export default config;
