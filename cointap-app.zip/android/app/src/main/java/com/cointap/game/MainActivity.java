package com.cointap.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
